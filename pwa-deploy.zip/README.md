# HTML to APK Studio: GitHub Pages PWA

Root files: `index.html`, `manifest.webmanifest`, `sw.js`, `icon-192.png`, `icon-512.png`, `icon-maskable-512.png`, `apple-touch-icon.png`, `404.html`
Optional: `.github/workflows/pages.yml`, `.nojekyll`

## Deploy (easiest, works from a phone)
1. github.com → New repository → set it to **Public**.
2. Add file → Upload files → select all root files above → Commit.
3. Settings → Pages → Source: **Deploy from a branch** → Branch `main`, folder `/ (root)` → Save.
4. After about a minute open `https://<username>.github.io/<repository>/`.

## Deploy with Actions (optional)
1. Add file → Create new file → name it `.github/workflows/pages.yml` and paste the workflow.
2. Settings → Pages → Source: **GitHub Actions**.
3. Every push to `main` redeploys.

## Install on Android
Open the URL in Chrome → ⋮ → **Install app**, or tap "Install this builder as an app" on the page.

## Update
Edit files, commit, then change `V` in `sw.js` (for example `apk-studio-v2`) so phones refresh their cache.

## Troubleshooting
- No Install option: use the https:// address, reload once so the service worker registers, then check ⋮ again.
- Old version still showing: bump `V` in `sw.js`, or clear the site's data in Chrome → Site settings.
- Apps made with the PWA package deploy the same way: one repository per app.
